                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2353657
Japanese Lantern Replica  by ProgressTH is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a Japanese-style lantern based off a design found online (comparison included). Modeled in SketchUp (file included), it is printed out in multiple parts that require assembly. The bottom requires support material, the top does not. 

Users are encouraged to modify and improve this design which is why the SketchUp file is also included.

Print Quantity (file names): 

(1) Base (Feet.stl) 
(1) Bottom (Btm.stl) 
(2) Brace Rings (BracesX2.stl) 
(6) Lantern Panels (PanelsX6.stl) 
(1) Top (Top.stl) 

Fasten the parts with either hot glue or friction welding. 

Use a keychain ring as a solid means of hanging the lantern, or simply place it on a table top. The feet are optional. We use felt squares hot glued to the bottom of the feet to give the lantern more character and a better finish.  

Use only LED's to light the lantern. Do not use candles because it's an obvious fire hazard.  

# Print Settings

Printer: ExtraBot 3020
Rafts: No
Supports: No
Resolution: Low 
Infill: 40% 

Notes: 
This model has been modified from a previous version. It now no longer requires any support material but some assembly is required.