                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2391390
Bike Phone Holder by juhyukhong is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Bike Phone Holder(width 55 ~ 85 mm)
You may need 3~4 M3x40↑, M3 nuts.

This is bike phone holder from two things;
- Handle Bar Mount from "Modular Bicycle Dashboard" https://www.thingiverse.com/thing:29860,
- M5 nut, knob, bolt, and clamps from "Modular Mounting System" https://www.thingiverse.com/thing:2194278


STL files:
* Handle_Bar_Mount_ID25: is 25mm inner diameter 
* Handle_Bar_Mount_ID30: is 30mm inner diameter 
* Phone_clamp_down_grab_mod_0d: is for handlebar
* Phone_clamp_down_grab_mod_90d: is for stem or top/down tube
* Phone_clamp_down_grab_mod_both: is 0d + 90d

# Print Settings

Printer: Creatable D3
Rafts: No
Supports: Yes
Resolution: 0.2
Infill: 50%