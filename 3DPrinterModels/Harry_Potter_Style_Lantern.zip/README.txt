                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2761044
Harry Potter Style Lantern by sascharossier is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

My Wife dreamed of a special Lantern for the Audiobook Corner in our Loft. She wanted it to be a weathered Harry Potter Style Thing. Spooky, hundreds of Years old, already a bit out of Square and Skewed, with Animals and a lot of little Ornaments included in the Design. So i hopped over to 3dMax and 3dCoat an styled this lantern from the Ground up. See the whole Build-Log on my Website: http://sascharossier.com/?p=44844

Since i printed the Thing Completely in PLA i use a LED-Filament Bulb that doesnt get hot when using the Lantern. 

The Files provided are only 10% of the Original Size. For Slicing you need to adjust the Size to your taste. I printed mine @ 650%, except the bulbholder which was printed @ 1000% to fit a standard E27 bulb-Socket.

# Print Settings

Printer: Creality CR-10 S5
Rafts: No
Supports: Yes
Resolution: 0.3
Infill: 7%