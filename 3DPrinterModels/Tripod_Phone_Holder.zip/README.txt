                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2192209
Tripod Phone Holder by Dymios is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is a tripod phone holder for devices with around 5 inches display. 

The bottom part is configured to allow a nut to be mounted. Tripods usually have a 1/4-20 inches screw thread ([Wikipedia link](https://en.wikipedia.org/wiki/British_Standard_Whitworth)). It was not so easy for me to find locally a suitable nut so I tried to print it by myself. It surprisingly works and I included its STL in this thing.

I printed this using PLA, but any rigid material could be used.

# Post-Printing

## Mount a spring

Drill a 1mm hole on the top and bottom components, in order to mount an expansion spring that will help in keeping the phone stick to the holder.
I used a 3.5mm long spring, you can easily find them in a local hardware store.

![Alt text](https://cdn.thingiverse.com/assets/73/f6/a3/24/ae/IMG_20170317_120504.jpg)

## Glue components

Put the top and bottom component inside one side of the body and glue up the bottom component with the body.

Finally, glue up the other side of the body paying attention to keep the top part sliding.